#ifndef OPTIMISER_H
#define OPTIMISER_H

#include "main.h"

bool localSearch(SOL &S, double &feasRatio, int &numMoves);

#endif //OPTIMISER_H
