#ifndef MOBJ_H
#define MOBJ_H

#include "main.h"

void doMultiObjOptimisation(list<SOL> &A);

#endif //MOBJ_H
