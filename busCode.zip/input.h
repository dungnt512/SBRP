#ifndef INPUT_H
#define INPUT_H

#include "main.h"

void readInput(string &infile);

#endif //INPUT_H

